#' show the web interface
#'
#'@export
#'@import shiny
#'@importFrom shinyjs hide show useShinyjs
#'@import ggplot2
#'@import plot3D
#'@import DIMBIO
startDimBioPlot <- function(){

  runApp("R/Interface")

}
