#' show the web interface
#'@export

startDimBioPlot <- function(){
  library("shiny")
  runApp("R/Interface")

}
