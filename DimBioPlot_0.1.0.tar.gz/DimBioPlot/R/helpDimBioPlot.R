#'DimBioPlot
#'
#'It is a package that allows the graphic exploration in the discrimination of dynamic simulation models of biological processes.
#'
#'
#'This package contains a function called.
#'
#'startDimBioPlot()
#'
#'When executing this function. an interface is shown which allows you to load a database containing the information of your studies.
#'
#'Example of the data:
#'
#'proccess realH realT simulationH simulationT
#'
#'V1  0,7155	0,3684	0,017	  0,9846
#'
#'V1  1,253   0,4785	0,1546	0,9905
#'
#'V2  6,735   1,965	  7,27	  1,75
#'
#'v2  2,195   0,7148	0,8288	1,034
#'
#'
#'
#'- Process allows you to study your data by treatment or all the complete data.
#'
#'- You can include n number of simulation columns, but it must match the number of study variables in this example there are two study variables H and T.
#'
#'- The data should always have that order from left to right.
#'
#' 1) process column.
#'
#' 2) columns of real data.
#'
#' 3) simulated data columns.
#'
#'- The names of the headers must be included can be called in any way.
#'
#'
#'
#'
#'- When there are three study variables you can graph in 3D.
#'
#' Example of data 3D
#'
#'
#'proccess realH realT realR simulationH simulationT simulacionR
#'
#'V1  0,7155	0,3200  0,3684	0,017	  0,9846  0,78
#'
#'V1  1,253   0,9905  0,4785	0,1546	0,9905  0,36
#'
#'V2  6,735   0,9905  1,965	  7,27	  1,75    0,12
#'
#'v2  2,195   0,7155  0,7148	0,8288	1,034   0,25
#'
#'
#'Others Examples of data
#'
#'1)
#'
#'proccess realH realT simulation1H simulation1T simulation2H simulation2T
#'
#'V1  0,7155	0,3684	0,017	  0,9846  0,23  0,65
#'
#'V1  1,253   0,4785	0,1546	0,9905  0,78  0,65
#'
#'V2  6,735   1,965	  7,27	  1,75    0,31  0,65
#'
#'v2  2,195   0,7148	0,8288	1,034   0,11  0,32
#'
#'
#'2)
#'
#'proccess realH realT realR simulation1H simulation1T simulacion1R simulation2H simulation2T simulacion2R
#'
#'V1  0,7155	0,3200  0,3684	0,017	  0,9846  0,78  0,7148	0,8288	1,034
#'
#'V1  1,253   0,9905  0,4785	0,1546	0,9905  0,36  0,4785	0,1546	0,9905
#'
#'V2  6,735   0,9905  1,965	  7,27	  1,75    0,12  1,75    0,31    0,65
#'
#'v2  2,195   0,7155  0,7148	0,8288	1,034   0,25  0,017	  0,9846  0,78
#'
#'
#'3)
#'
#'proccess realH simulation1H simulation2H simulation3H simulation4H Simulation5H
#'
#'V1  0,7155	0,3684	0,017	  0,9846  0,23  0,2
#'
#'V1  1,253   0,4785	0,1546	0,9905  0,78  0,1
#'
#'V2  6,735   1,965	  7,27	  1,75    0,31  0,65
#'
#'v2  2,195   0,7148	0,8288	1,034   0,11  0,32
#'
#'@docType package
#'
#'@author Oneiber Quintero \email{oneiber.quintero@unet.edu.ve}, Alexis Valery \email{avalery@unet.edu.ve}
#'
#'@name helpDimBioPlot
#'
NULL
