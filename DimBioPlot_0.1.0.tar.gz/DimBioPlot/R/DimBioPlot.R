#'DimBioPlot
#'
#'It is a package that allows the graphic exploration in the discrimination of dynamic simulation models of biological processes.
#'
#'
#'This package contains a function called.
#'
#'startDimBioPlot()
#'
#'
#'@docType package
#'
#'@author Oneiber Quintero \email{oneiber.quintero@unet.edu.ve}, Alexis Valery \email{avalery@unet.edu.ve}
#'
#'@name DimBioPlot
#'
NULL
