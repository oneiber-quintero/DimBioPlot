library(shiny)
library(shinyjs)
library(DT)


# Define UI for application that draws a histogram
shinyUI(fluidPage(
    useShinyjs(),
    # Application title

    navbarPage("DIMBIOPLOT",
        tabPanel("Upload Data",
                 titlePanel("My Data"),
                 fileInput("getFile", "Upload File"),
                 textOutput("mensaje"),
                 fluidRow(column(DT::dataTableOutput("myData"),width = 12))

        ),
        tabPanel("Graphics of points",
                 titlePanel("Graphics of points"),
                 sidebarLayout(

                     div(id="panelGraphicsOfPoints",sidebarPanel(
                         fluidRow(
                            column(
                                width = 12,
                                tags$label( "Add the names of the variables of study" )
                            ),
                            column(
                                width = 8,
                                textInput( inputId = "InputNames",label = NULL, placeholder = "write your variable" )
                            ),
                            column(
                                width = 2,
                                actionButton("add","Add")
                            ),
                            column(
                                width = 12,
                                selectInput( inputId = "listVariableName", label = NULL,choices = NULL,multiple = TRUE, selected = "-1")
                            )
                         ),


                         selectInput( inputId = "typeOfDistance", label = "Choose a type of distance",choices = c("choose a type"="-1")),

                         selectInput(inputId = "processing", label = "Choose your processing",choices = c("all the data as a processing"="-1")),

                         checkboxGroupInput(inputId = "simulations",label=""),

                         textInput( inputId = "titleGraphic", label = "Title Graphic", placeholder = "write the title for the graphic" ),
                         tags$label( "axis labels (x,y,z)" ),
                         textInput( inputId = "xlabel", label = NULL, placeholder = "write the label X" ),
                         textInput( inputId = "ylabel", label = NULL, placeholder = "write the label Y" ),
                         div(id="divZLabel",
                             textInput( inputId = "zlabel", label = NULL, placeholder = "write the label Z" )
                         ),
                         fluidRow(
                             column(
                                 width = 12,
                                 tags$label( "Add the names for the legend" )
                             ),
                             column(
                                 width = 8,
                                 textInput( inputId = "InputNamesLegend",label = NULL, placeholder = "write your name legend" )
                             ),
                             column(
                                 width = 2,
                                 actionButton("addLegend","Add")
                             ),
                             column(
                                 width = 12,
                                 selectInput( inputId = "listLegendName", label = NULL,choices = NULL,multiple = TRUE, selected = "-1")
                             )
                         ),
                         div(id="slider3D",
                            sliderInput(inputId = "moveHorizontal", label = "rotate horizontal", min = 0, max = 360, value = 30 ),
                            sliderInput(inputId = "moveVertical", label = "rotate vertical", min = 0, max = 360, value = 0)
                         ),
                         actionButton("submitPoints","OK", class="btn-success",)
                     )),
                     mainPanel(
                        textOutput("msjGraphicPoints"),
                        plotOutput("graphicPoints"),
                        textOutput("temp1")
                     )
                 )
        ),
        tabPanel("Graphics of Bars",
                 titlePanel("Graphics of Bars"),
                 sidebarLayout(
                     div(id="panelGraphicsOfBars",sidebarPanel(
                         fluidRow(
                             column(
                                 width = 12,
                                 tags$label( "Add the names of the variables of study" )
                             ),
                             column(
                                 width = 8,
                                 textInput( inputId = "InputNames2",label = NULL, placeholder = "write your variable" )
                             ),
                             column(
                                 width = 2,
                                 actionButton("add2","Add")
                             ),
                             column(
                                 width = 12,
                                 selectInput( inputId = "listVariableName2", label = NULL,choices = NULL,multiple = TRUE, selected = "-1")
                             )
                         ),
                         selectInput( inputId = "typeOfStadistic", label = "Choose a type of stadistic",choices = c("choose a type"="-1")),
                         selectInput(inputId = "processing2", label = "Choose your processing",choices = c("all the data as a processing"="-1")),
                         checkboxGroupInput(inputId = "simulations2",label=""),
                         textInput( inputId = "titleGraphic2", label = "Title Graphic", placeholder = "write the title for the graphic" ),
                         tags$label( "Axis labels (x,y)" ),
                         textInput( inputId = "xlabel2", label = NULL, placeholder = "write the label X" ),
                         textInput( inputId = "ylabel2", label = NULL, placeholder = "write the label Y" ),
                         fluidRow(
                             column(
                                 width = 12,
                                 tags$label( "Add the names for the group" )
                             ),
                             column(
                                 width = 8,
                                 textInput( inputId = "InputNamesLegend2",label = NULL, placeholder = "write your name group" )
                             ),
                             column(
                                 width = 2,
                                 actionButton("addLegend2","Add")
                             ),
                             column(
                                 width = 12,
                                 selectInput( inputId = "listLegendName2", label = NULL,choices = NULL,multiple = TRUE, selected = "-1")
                             )
                         ),
                         actionButton("aceptar","OK", class="btn-success",)


                     )),
                     mainPanel(
                         textOutput("mensaje2"),
                         plotOutput("graphicBars"),
                         textOutput("temp2")
                     )
                 )
        )
    )

    # Sidebar with a slider input for number of bins

))
