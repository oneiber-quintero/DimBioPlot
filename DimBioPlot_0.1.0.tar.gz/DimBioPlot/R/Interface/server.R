library(shiny)
library(ggplot2)
library(plot3D)
library(DIMBIO)
library(DT)



# Define server logic required to draw a histogram
shinyServer(function(input, output,session) {

    shinyjs::hide(id = "panelGraphicsOfPoints")
    shinyjs::hide(id = "panelGraphicsOfBars")
    shinyjs::hide(id = "slider3D")
    shinyjs::hide(id = "divZLabel")


    ##cargando y mostrando la data
    output$mensaje <- renderText({

      infile <- input$getFile

      if(is.null(infile)){
        return( "Upload your data please." )
      }else{

        data <- read.delim2( as.character( infile$datapath ) )
        basededatos <<- data
        output$myData <- DT::renderDataTable(

          DT::datatable(
            {data},
            options = list( lengthMenu = list( c( 15, 25, 50, -1 ), c( "15", "25", "50", "all" ) ), pageLength = 15, initComplete = JS(
              "function(settings, json) {",
              "$(this.api().table().header()).css({'background-color': '#3B83bd', 'color': '#fff'});",
              "}") ),
            selection = "multiple",
            style = "bootstrap"
          )
        )

        shinyjs::show( id = "panelGraphicsOfPoints" )

        #cargando las opciones principales

        #tratamientos
        optionsNames <- c( "all the data as a processing", as.vector( unique(basededatos[,1] ) ) )
        optionsValues <- c( "-1", as.vector( unique( basededatos[,1] ) ) )
        optionsProcessing <- optionsValues
        names( optionsProcessing ) <- optionsNames

        updateSelectInput(
          session = session,
          inputId = "processing",
          label = "Choose your processing",
          choices = optionsProcessing
        )

        #tipo de distancia points
        updateSelectInput(
          session = session,
          inputId = "typeOfDistance",
          label = "Choose a type of distance",
          choices = c(
            "hidden the distance" = "-1",
            "Euclidiana" = "euc"
            #"Manhattan" = "man",
            #"Mahalanobis" = "mah"
          ),
        )

        #movimiento Horizontal
        numberVariablesCheck <<- 0;

        return("")
      }
    })


    output$temp1 <-renderText({

      infile <- input$getFile
      if( is.null( infile ) ){

        output$msjGraphicPoints <- renderText({
          return ("Upload your data please.")
        })

      }else{

        output$msjGraphicPoints <- renderText({
          return ("")
        })

        variableStudy <<- input$listVariableName

        #simulaciones checkbox
        if( !is.null( variableStudy ) && ( ( length( variableStudy ) != length( numberVariablesCheck ) || numberVariablesCheck == 0 ) ) ){
          numberVariablesCheck <<- input$listVariableName
          variableStudy <- length( variableStudy )
          separateSimulation <- c( 1:variableStudy ) + ( 1 + variableStudy )
          namesforChecks <- as.vector( paste( "Group",paste( names( basededatos )[separateSimulation[1]], "...", sep="" ),sep = " " ) )
          numberSimulations <- ( ncol( basededatos ) - ( 1 + variableStudy ) )/ variableStudy
          if( numberSimulations > 1 ){
            for (i in 2: numberSimulations ) {
              separateSimulation <- separateSimulation +  variableStudy
              namesforChecks <- c( namesforChecks, as.vector( paste( "Group",paste( names( basededatos )[separateSimulation[1]], "...", sep="" ),sep = " " ) ) )
            }
          }

          updateCheckboxGroupInput(
            session = session ,
            inputId = "simulations",
            label =  "Choose your columns for the simulations ",
            choiceNames = namesforChecks,choiceValues = c( 1:length(namesforChecks ) ),
            selected = c( 1:length(namesforChecks ) )
          )
        }

        numberSimulations <<- length( input$simulations )
        numberGraphics <<- numberSimulations + 1
        variableStudy <- input$listVariableName
        if( !is.null( variableStudy ) && length( variableStudy ) == 3 ){
          shinyjs::show(id = "slider3D")
          shinyjs::show(id = "divZLabel")
        }else{
          shinyjs::hide(id = "slider3D")
          shinyjs::hide(id = "divZLabel")
        }


        #nombres para la legenda al borrar y escribir y limpiar
        if( numberSimulations == 0 ){
          updateSelectInput(
            session = session,
            inputId = "listLegendName",
            label = NULL,
            selected = c(""),
            choices = c("")
          )
        }

      }
      return("")
    })

    #agregar variables de estudio grafico de points
    observeEvent( input$add, {

      listaNames <- input$listVariableName
      if( length( listaNames ) < 3 ){
        listaNames <- c(listaNames,input$InputNames)
        updateSelectInput(
          session = session,
          inputId = "listVariableName",
          label = NULL,
          selected = listaNames,
          choices = listaNames
        )
      }
      updateTextInput(
        session= session,
        inputId = "InputNames",
        label = NULL,
        value = ""
      )
    })

    #agregar nombres de la legenda a la lista
    observeEvent( input$addLegend, {
      listLegendNames <- input$listLegendName
      if( numberGraphics != 1 && length( listLegendNames ) < numberGraphics ){
        listLegendNames <- c( listLegendNames, input$InputNamesLegend )
        updateSelectInput(
          session = session,
          inputId = "listLegendName",
          label = NULL,
          selected = listLegendNames,
          choices = listLegendNames
        )
      }
      updateTextInput(
        session= session,
        inputId = "InputNamesLegend",
        label = NULL,
        value = ""
      )
    })

    observeEvent(input$submitPoints, {

      simulationsColumn <<- input$simulations
      namesLegend <<- input$listLegendName
      variableStudy <<- input$listVariableName
      processing <<- input$processing
      distance <<- input$typeOfDistance
      moveHorizontal <<- input$moveHorizontal
      moveVertical <<- input$moveVertical
      titleGraphic <<-input$titleGraphic
      xlabel <<- input$xlabel
      ylabel <<- input$ylabel
      zlabel <<- input$zlabel
      numberGraphics <<- length( simulationsColumn ) + 1

      if( processing == -1 ){ processing <<- NULL }

      if( titleGraphic == "" ){ titleGraphic <<- NULL }

      if( xlabel == "" ){ xlabel <<- NULL }

      if( ylabel == "" ){ ylabel <<- NULL }

      if( zlabel == "" ){ zlabel <<- NULL }

      namesLegend <<- input$listLegendName
      if( length( namesLegend ) > numberGraphics ){
        namesLegend <<- namesLegend[1:numberGraphics]
        updateSelectInput(
          session = session,
          inputId = "listLegendName",
          label = NULL,
          selected = namesLegend,
          choices = namesLegend
        )
      }else if( numberGraphics != 1 &&  !is.null ( namesLegend ) && length( namesLegend ) <= numberGraphics  ){
        namesLegend <<- input$listLegendName
        if( length( namesLegend ) != numberGraphics  ){
        namesLegend <<- c(as.vector(namesLegend), c( ( 1 + length( namesLegend ) ):numberGraphics ) )
        }else{
          namesLegend <<- as.vector(namesLegend)
        }
      }else if( numberGraphics == 1 ){
        namesLegend <<- input$listLegendName
      }


      if( !is.null( simulationsColumn ) ){

        simulationsColumn <- as.numeric(as.vector(simulationsColumn))
        output$graphicPoints <- renderPlot({
            graphic_of_points(data = basededatos,studyVariables = variableStudy ,typeOfDistance = distance, processing = processing, simulations = simulationsColumn, nameForLegend = namesLegend, xlab = xlabel, ylab = ylabel, zlab = zlabel, title = titleGraphic, moveHorizontal = moveHorizontal, moveVertical = moveVertical )
        })

      }else{

        updateSelectInput(
          session = session,
          inputId = "listLegendName",
          label = NULL,
          selected = c(""),
          choices = c("")
        )
        output$graphicPoints <- renderPlot({
          FALSE
        })
      }
    })













    ###############################################################################
    ############################ codigo para las barras ###########################
    ###############################################################################





    ######barplot

    ##cargando y mostrando la data
    output$mensaje2 <- renderText({
      infile <- input$getFile
      if(is.null(infile)){

        return( "Upload your data please." )
      }else{

        shinyjs::show(id = "panelGraphicsOfBars")


        #tratamientos
        optionsNames <- c( "all the data as a processing",as.vector(unique(basededatos[,1])))
        optionsValues <- c( "-1",as.vector(unique(basededatos[,1])))
        optionsProcessing <- optionsValues
        names(optionsProcessing) <- optionsNames

        updateSelectInput(
          session = session,
          inputId = "processing2",
          label = "choose your processing",
          choices = optionsProcessing
        )

        #tipo de estadistico
        updateSelectInput(
          session = session,
          inputId = "typeOfStadistic",
          label = "choose a type of stadistic",
          choices = c(
            "Percent root mean square error(%RMSE)" = "X.RMSE",
            "The Nash–Sutcliffe efficiency index(NS)" = "NS",
            "Mean squared error of the predictions(MSEP)" = "MSEP",
            "Root Mean Square Error of Prediction(RMSEP)" = "RMSEP",
            "Mean absolute error(MAE)" = "MAE",
            "Mean absolute percentage error(MAPE)" = "X.MAE",
            "Coefficient inequality(u)" = "U",
            "Goodness of fit statistics(R2)" = "R.2",
            "Pearson correlation coefficient" = "pearson",
            "Maximum likelihood estimation(MLE)" = "MV",
            "Akaike information coefficient(AIC)" = "AIC",
            "Bias error(intercept)(MC)" = "MC",
            "Unit error(Slope)(SC)" = "SC",
            "Random error(RC)" = "RC",
            "Students T Distribution" = "t.student",
            "bayes theorem" = "bayes"
          ),
        )

        numberVariablesCheck2 <<- 0;

        return("")
      }
    })

    output$temp2 <-renderText({
      infile <- input$getFile
      if( is.null(infile)){
        output$mensaje1 <- renderText({
          return("Upload your data please.")
        })
      }else{

        output$mensaje2 <- renderText({
          return("")
        })


        # columnas de simulacion para los checkbox
        variableStudy <- input$listVariableName2
        if( !is.null( variableStudy ) && ( ( length( variableStudy ) != length( numberVariablesCheck2 ) || numberVariablesCheck2 == 0 ) ) ){
          numberVariablesCheck2 <<- input$listVariableName2
          variableStudy <- length( variableStudy )
          separateSimulation <- c( 1:variableStudy ) + ( 1 + variableStudy )
          namesforChecks <- as.vector( paste( "Group",paste( names( basededatos )[separateSimulation[1]], "...", sep="" ),sep = " " ) )

          numberSimulations <- ( ncol( basededatos ) - ( 1 + variableStudy ) )/ variableStudy
          if( numberSimulations > 1 ){
            for (i in 2: numberSimulations ) {
              separateSimulation <- separateSimulation +  variableStudy
              namesforChecks <- c( namesforChecks, as.vector( paste( "Group",paste( names( basededatos )[separateSimulation[1]], "...", sep="" ),sep = " " ) ) )
            }
          }

          updateCheckboxGroupInput(
            session = session ,
            inputId = "simulations2",
            label =  "Choose your columns for the simulations ",
            choiceNames = namesforChecks,choiceValues = c( 1:length(namesforChecks ) ),
            selected = c( 1:length(namesforChecks ) )
          )
        }
        #})
        numberSimulations2 <- length( input$simulations2 )
        numberGraphics <<- numberSimulations2

      }
      return ("")
    })

    #agregando variable de estudios para la grafica de barras
    observeEvent( input$add2, {
      listaNames2 <- input$listVariableName2
      listaNames2 <- c( listaNames2, input$InputNames2 )
      updateSelectInput(
        session = session,
        inputId = "listVariableName2",
        label = NULL,
        selected = listaNames2,
        choices = listaNames2
      )
      updateTextInput(
        session= session,
        inputId = "InputNames2",
        label = NULL,
        value = ""
      )
    })

    #agregar nombres la los grupos de simulacion
    observeEvent( input$addLegend2, {
      listLegendNames2 <- input$listLegendName2

      if( numberGraphics != 0 && length( listLegendNames2 ) < numberGraphics  ){
        listLegendNames2 <- c( listLegendNames2, input$InputNamesLegend2 )
        updateSelectInput(
          session = session,
          inputId = "listLegendName2",
          label = NULL,
          selected = listLegendNames2,
          choices = listLegendNames2
        )
      }
      updateTextInput(
        session= session,
        inputId = "InputNamesLegend2",
        label = NULL,
        value = ""
      )
    })

    #boton de graficar
    observeEvent( input$aceptar, {
      simulationsColumn2 <<- input$simulations2
      typeOfStadistic <<- input$typeOfStadistic
      namesLegend2 <<- input$listLegendName2
      variableStudy2 <<- input$listVariableName2
      processing2 <<- input$processing2
      titleGraphic2 <<-input$titleGraphic2
      xlabel2 <<- input$xlabel2
      ylabel2 <<- input$ylabel2
      numberGraphics <<- length( input$simulations2 )
      if( processing2 == -1){ processing2 <<- NULL }

      if( titleGraphic2 == "" ){ titleGraphic2 <<- NULL }

      if( xlabel2 == "" ){ xlabel2 <<- NULL }

      if( ylabel2 == "" ){ ylabel2 <<- NULL }

      if( length( namesLegend2 ) > numberGraphics ){
        namesLegend2 <<- namesLegend2[1:numberGraphics]
        updateSelectInput(
         session = session,
         inputId = "listLegendName2",
         label = NULL,
         selected = namesLegend2,
         choices = namesLegend2
        )
      }else if( numberGraphics != 1 &&  !is.null ( namesLegend2 ) && length( namesLegend2 ) < numberGraphics  ){
        namesLegend2 <<- input$listLegendName2
        namesLegend2 <<- c( as.vector( namesLegend2 ), c( ( 1 + length( namesLegend2 ) ):numberGraphics ) )
      }else if( numberGraphics == 1 ){
        namesLegend2 <<- input$listLegendName2
      }

      if( !is.null( simulationsColumn2 ) ){
        simulationsColumn2 <- as.numeric( as.vector( simulationsColumn2 ) )
        output$graphicBars <- renderPlot({
          graphic_of_bars(data = basededatos, studyVariables = variableStudy2 ,type = typeOfStadistic, processing = processing2, simulations = simulationsColumn2, namesByGroups = namesLegend2, xlab = xlabel2, ylab = ylabel2, title = titleGraphic2 )
        })
      }else{
        updateSelectInput(
          session = session,
          inputId = "listLegendName2",
          label = NULL,
          selected = c(""),
          choices = c("")
        )
        output$graphicBars <- renderPlot({
          FALSE
        })
      }
    })

})









#######################################################################################
#######################################################################################
#######################################################################################
#######################################################################################
#######################################################################################
#######################################################################################
#######################################################################################
#######################################################################################























graphic_of_points <- function( data = NULL, studyVariables = NULL, typeOfDistance = NULL, processing = NULL, simulations = NULL, nameForLegend = NULL, xlab = NULL, ylab = NULL, zlab = NULL, title=NULL, moveHorizontal = NULL, moveVertical = NULL ){

  start <- 0
  #fields required
  if( !is.null( data ) && is.data.frame( data ) ){
    if( !is.null( studyVariables ) && is.vector(studyVariables) && length( studyVariables ) < 4 ){
      start <- 1
    }else{
      print("Error. study Variables no found... max 3 variables");
    }
  }else{
    print("Error. data no found...");
  }

  if( start == 1 ){

    database <- data
    numberOfVariables <- length( studyVariables )
    numberSimulations <- ( ncol( database ) - numberOfVariables ) / numberOfVariables

    #labels axis validations defaults
    if( is.null( xlab ) ){
      if( numberOfVariables == 1 ){
        xlab <- "dias"
      }else{
        xlab <- studyVariables[1]
      }
    }
    if( is.null( ylab ) ){
      if( numberOfVariables == 1 ){
        ylab = studyVariables[1]
      }else{
        ylab = studyVariables[2]
      }
    }
    if( is.null( zlab ) && numberOfVariables == 3 ){
      zlab = studyVariables[3]
    }

    if( is.null( title ) ){
      title <- "graphic"
    }

    if( numberOfVariables == 3 ){
      if( is.null( moveHorizontal ) ){
        moveHorizontal <- 30
      }
      if( is.null( moveVertical ) ){
        moveVertical <- 0
      }
    }


    #filter proccesing
    if( !is.null( processing ) ){
      names( database )[1] <- "xprocessing"
      database <- subset( database, xprocessing == processing )
      database <- database[,c( 2:ncol( data ) )]
    }else{
      database <- data[,c( 2:ncol( data ) )]
    }

    if( ncol( database ) > numberOfVariables*2 ){
      #filter simulations
      if( !is.null( simulations ) ){
        if( is.vector( simulations ) && length( simulations ) >= 1 ){
          simulations <- unique( simulations )
          simulationSeparator <- c( 1:numberOfVariables )
          selectedSimulations <- simulationSeparator
          for( i in simulations ){
            if( i <= numberSimulations ){
              selectedSimulations <- c( selectedSimulations, simulationSeparator + ( numberOfVariables * i ) )
            }else{
              print("Error there is no simulation in the indicated position")
            }
          }
          database <- database[,selectedSimulations]
        }
      }else{
        simulations <- c( 1:numberSimulations )
      }

      #type of distance
      if( !is.null( typeOfDistance ) && typeOfDistance == "euc" ){
        centroids <- colMeans( database )
      }else if( !is.null( typeOfDistance ) && typeOfDistance == "man" ){

      }else if( !is.null( typeOfDistance ) && typeOfDistance == "mah" ){

      }else{
        centroids = NULL
      }

      numberOfGraphics <- ( length( database ) / numberOfVariables )
      #legend per default
      if( is.null( nameForLegend ) ){
        nameForLegend <- c( 1:numberOfGraphics )
      }

      simulationSeparator <- c( 1:numberOfVariables )
      if( numberOfVariables < 3 ){
        graphic <- ggplot()
      }
      numberRow = nrow( database )
      #points centroids, newData
      x <- y <- z <- g <- NULL
      for( i in 1:numberOfGraphics  ){
        #points centroids
        if( !is.null( centroids ) ){
          if( numberOfVariables == 1 ){
            x <- c( x, mean( c( 1:numberRow ) ) )
            y <- c( y, centroids[simulationSeparator[1]] )
            g <- c( g, i )
          }else if( numberOfVariables == 2 ){
            x <- c( x, centroids[simulationSeparator[1]] )
            y <- c( y, centroids[simulationSeparator[2]] )
            g <- c( g, i )
          }else{
            x <- c( x, centroids[simulationSeparator[1]] )
            y <- c( y, centroids[simulationSeparator[2]] )
            z <- c( z, centroids[simulationSeparator[3]] )
            g <- c( g, i )
          }
        }
        #data
        if( numberOfVariables == 1 ){
          x <- c( x, c( 1:numberRow ) )
          y <- c( y, database[,simulationSeparator[1]] )
          g <- c( g, rep( i, numberRow ) )
        }else if( numberOfVariables == 2  ){
          x <- c( x, database[,simulationSeparator[1]] )
          y <- c( y, database[,simulationSeparator[2]] )
          g <- c( g, rep( i, numberRow ) )
        }else{
          x <- c( x, database[,simulationSeparator[1]] )
          y <- c( y, database[,simulationSeparator[2]] )
          z <- c( z, database[,simulationSeparator[3]] )
          g <- c( g, rep( i, numberRow ) )
        }

        simulationSeparator <- simulationSeparator + numberOfVariables
      }

      if( numberOfVariables < 3 ){
        newData <- data.frame( x = x, y = y, g = g )
        legend <- factor( newData$g, labels = nameForLegend )
        graphic = graphic + geom_point( data = newData, aes( x = x, y = y, color = legend ) )
      }else{
        legend <- as.character( nameForLegend )
        newData <- data.frame( x = x, y = y, z = z, g = g )
      }


      #newData for the lines
      if( !is.null( centroids ) ){
        if( numberOfVariables == 1 ){
          x <- mean( c( 1:nrow( database ) ) )
          y <- centroids[1]
          g <- 1
        }else if( numberOfVariables == 2 ){
          x <- centroids[1]
          y <- centroids[2]
          g <- 1
        }else{
          x <- centroids[1]
          y <- centroids[2]
          z <- centroids[3]
          g <- 1
        }

        if( numberOfVariables < 3 ){
          x <- rep( x, numberOfGraphics - 1  )
          y <- rep( y, numberOfGraphics - 1  )
          g <- rep( g, numberOfGraphics - 1  )
        }else{
          x <- rep( x, numberOfGraphics - 1  )
          y <- rep( y, numberOfGraphics - 1  )
          z <- rep( z, numberOfGraphics - 1  )
          g <- rep( g, numberOfGraphics - 1  )
        }

        simulationSeparator <- c( 1:numberOfVariables )
        simulationSeparator <- simulationSeparator + numberOfVariables
        for( i in 2:numberOfGraphics ){
          if( numberOfVariables == 1 ){
            x <- c( x, mean( c( 1:numberRow ) )  )
            y <- c( y, centroids[simulationSeparator[1]]  )
            g <- c( g, 1  )
          }else if( numberOfVariables == 2 ){
            x <- c( x, centroids[simulationSeparator[1]]  )
            y <- c( y, centroids[simulationSeparator[2]]  )
            g <- c( g, 1  )
          }else{
            x <- c( x, centroids[simulationSeparator[1]]  )
            y <- c( y, centroids[simulationSeparator[2]]  )
            z <- c( z, centroids[simulationSeparator[3]]  )
            g <- c( g, 1  )
          }

          simulationSeparator <- simulationSeparator + numberOfVariables
        }
        g <- rep( c( 1:( length( g ) / 2 ) ),2)

        if( numberOfVariables < 3 ){
          newDataForTheLines <- data.frame( x = x, y = y, g = g )
          graphic = graphic + geom_line( data = newDataForTheLines, aes( x = x, y = y, group = g ) )
        }else{
          newDataForTheLines <- data.frame( x = x, y = y, z = z, g = g )
        }
      }
      #add labels to the graphic
      if( numberOfVariables < 3 ){
        graphic <- graphic + labs( x = xlab, y = ylab  )
        graphic <- graphic + ggtitle( title )
        graphic
      }else{
        # 3 dimensiones
        colorCenter <- numberOfGraphics - 1
        colorCenter <- colorCenter / numberOfGraphics
        colorCenter <- ( ( c( 1:numberOfGraphics ) * colorCenter ) + 1 ) - ( colorCenter / 2 )
        colors <- rainbow( numberOfGraphics )
        graphic <- scatter3D( newData$x, newData$y, newData$z, colkey = list( length = 0.3, width = 0.5, addlines = TRUE, at = colorCenter, labels = legend ), clab = "Legend", xlab = xlab, ylab = ylab, zlab = zlab, colvar = newData$g, col = colors, main = title, ticktype = "detailed", pch = 20, type = "p", bty = "g", phi = moveVertical, theta = moveHorizontal )
        #paint centroids
        if( !is.null( centroids ) ){
          for( i in 1:length( simulations )  ){
            tempData <- newDataForTheLines
            tempData <- subset( tempData, g == i )
            graphic = graphic + lines3D( tempData$x, tempData$y, tempData$z, add = TRUE, colvar = tempData$g, colkey = FALSE, col = "black", ticktype = "detailed", pch = 20, type = "l", bty = "g", phi = 0 )
          }
        }

      }



    }else{
      print("Error. you need at least one real data column and one simulated data column");
    }

  }
}



graphic_of_bars <- function( data = NULL, type = NULL, studyVariables = NULL ,processing = NULL, simulations = NULL, xlab = NULL, ylab = NULL, title = NULL, namesByGroups = NULL ){

  start <- 0
  #fields required
  if( !is.null( data ) && is.data.frame( data ) ){
    if( !is.null( type ) && is.character( type ) ){
      if( !is.null( studyVariables ) && is.vector(studyVariables) ){
        start <- 1
      }else{
        print("Error. study Variables no found...");
      }
    }else{
      print("Error. type no found...");
    }
  }else{
    print("Error. data no found...");
  }


  if( start == 1 ){

    ########creando data frame de datos univariantes
    database <- data
    numberOfVariables <- length( studyVariables )

    #axis x, y defaults
    if( is.null( xlab ) ){
      xlab <- "simulations"
    }
    if( is.null( ylab ) ){
      ylab <- type
    }

    #filter proccesing
    if( !is.null( processing ) ){
      names( database )[1] <- "xprocessing"
      database <- subset( database,xprocessing == processing )
      database <- database[,c( 2:ncol( data ) )]
    }else{
      database <- data[,c( 2:ncol( data ) )]
    }

    if( ncol( database ) > numberOfVariables*2 ){

      #filter simulations
      numberSimulations <- ( ncol( database ) - numberOfVariables ) / numberOfVariables
      if( !is.null( simulations ) ){
        if( is.vector( simulations ) && length( simulations ) >= 1 ){
          simulations <- unique( simulations )
          simulationSeparator <- c( 1:numberOfVariables )
          selectedSimulations <- simulationSeparator
          for( i in simulations ){
            if( i <= numberSimulations ){
              selectedSimulations <- c( selectedSimulations, simulationSeparator + ( numberOfVariables * i ) )
            }else{
              print("Error there is no simulation in the indicated position")
            }
          }
          database <- database[,selectedSimulations]
        }
      }else{
        simulations <- c( 1:numberSimulations )#( ncol( database ) / numberOfVariables )
      }

      #filter data for a single study variable
      dataReal <- database[,c(1:numberOfVariables)]
      if( numberOfVariables == 1 ){
        dataReal <- data.frame( x = dataReal )
        names( dataReal ) <- names( database )[1]
      }

      dataUnivariantes <- data.frame()
      simulationSeparator <- c(1:numberOfVariables)
      for ( i in 2:( ncol( database ) / numberOfVariables ) ) {
        simulationSeparator <- simulationSeparator + numberOfVariables
        dataSimulated <- database[,simulationSeparator]
        if( numberOfVariables == 1 ){
          dataSimulated <- data.frame( x = dataSimulated )
          names( dataSimulated ) <- names( database )[i]
        }
        temporal <- Univariantes( dataReal, dataSimulated )
        namesSimulated <- names( dataSimulated )
        row.names( temporal ) <- namesSimulated
        dataUnivariantes <- rbind( dataUnivariantes, temporal )
        #print(dataUnivariantes)
      }

      #graphing
      found <- FALSE
      j <- 1
      type <- toupper( type )
      for ( i in names( dataUnivariantes ) ) {
        if( toupper( i ) == type ){
          y <- dataUnivariantes[,j]
          x <- rep( 1, length( studyVariables ) )
          if( length( simulations ) > 1 ){
            for( j in 1:( length( simulations ) - 1)  ){
              x <- c( x, rep( j + 1 ,length( studyVariables ) ) )
            }
          }

          if( !is.null( namesByGroups ) ){
            x <- factor( x, labels = namesByGroups )
          }

          legend <- rep( studyVariables, length( simulations ) )
          newData <- data.frame( x = x, y = y, legend = legend )
          graphic <- ggplot( data = newData, aes( x = x, y = y, fill = legend  ) ) + geom_col( position = position_dodge2() )

          found <- TRUE
        }
        j = j + 1
      }
      if( found ){
        if( is.null( title ) ){
          title <- paste( "graphic", type, sep=" " )
        }
        graphic <- graphic + ggtitle( title )
        graphic <- graphic + labs( x = xlab, y = ylab  )
        graphic
      }else{
        print("Error. statistic name not found")
      }
    }else{
      print("Error. you need at least one real data column and one simulated data column");
    }
  }

}

